# Real_Time_Object_Detection_Using_YOLOV3_and_OpenCV

Step 1: To run this algorithm: Add yolov3.weights or yolov3tiny.weights file in your folder. You can download weights from [here](https://pjreddie.com/darknet/yolo/) \
Step 2: Don't forget to install all the dependencies which are being errored out in the first run. 
